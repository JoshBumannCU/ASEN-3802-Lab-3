
function [] = Part3Plots(Cl,Cd_i,OddTerms,N1cdi,N10cdi,N01cdi,N1cl,N10cl,N01cl)

% OddTerms: number of odd terms used (n)
% Cl: coefficent of lift
% Cl_actual: the actual Cl value
% Cd_i: Coefficent of Induced Drag
% Cd_i_actual: the actual Cdi value
% N1cdi,N10cdi,N01cdi,N1cl,N10cl,N01cl = N values for 1, 10 and 0.1 % error for Cdi and cl

% Plots for 2
figure()
hold on;
grid on;
plot(OddTerms, Cl)
xline(N10cl, 'r--')
xline(N1cl, 'b--')
xline(N01cl, 'g--')
title('C_L vs Number of Odd Terms')
ylabel('C_L')
xlabel('Number of Odd Terms')
legend('C_L','10% Error','1% Error','0.1% Error','Location','northeast')

figure()
hold on;
grid on;
plot(OddTerms,Cd_i)
xline(N10cdi, 'r--')
xline(N1cdi, 'b--')
xline(N01cdi, 'g--')
title('C_{D,i} vs Number of Odd Terms')
ylabel('C_{D,i}')
xlabel('Number of Odd Terms')
legend('C_{D,i}','10% Error','1% Error','0.1% Error','Location','northeast')

% Plots for 3


end
