function [L, Di, D, LD] = LiftDragFunction(cd,Cl,Cdi,AoA_values,doPlot)

% givens
V = 100 * 1.688; % ft/s
h = 10000; % ft
rho = 0.001756; % slugs/ft^3
b = 33 + 4/12; %ft
cr = 5 + 4/12; %ft
ct = 3 + 8.5/12; %ft
S = b/2 * (cr + ct);

% Calculate L, Di, D and L/D
L = Cl .* 0.5 * rho * V^2 * S;
Di = 0.5 * rho * V^2 * S .* Cdi;

Cd = cd' + Cdi;
D =  0.5 * rho * V^2 * S .* Cd;

LD = L ./ D;

% Plot (deliverables 4&5)

if doPlot

figure()
hold on;
grid on;
plot(AoA_values,Cd)
plot(AoA_values,cd)
plot(AoA_values,Cdi)
xlabel('Angle of Attack (deg)')
ylabel('Drag Coefficient')
title('Drag Coefficients vs Angle of Attack')
legend('Total Drag, C_D', 'Profile Drag, c_d', 'Induced Drag, C_{D,i}', ...
    'Location', 'northwest')
hold off;

figure()
hold on;
grid on;
plot(AoA_values,LD)
title('Aerodynamic Efficiency vs Angle of Attack')
xlabel('Angle of Attack (deg)')
ylabel('Aerodynamic Efficiency, L/D')

% Finding and marking the max L/D and at the corresponding value of AoA
[max_LD, max_LD_index] = max(LD);
AoA_max_LD = AoA_values(max_LD_index);
plot(AoA_max_LD, max_LD, 'o', 'MarkerSize', 8, 'LineWidth', 2)
legend('L/D', 'Maximum L/D', 'Location', 'northwest')
% Adding results to subtitle for better readability
subtitle(sprintf('Maximum L/D = %.2f at AoA = %.2f deg', max_LD, AoA_max_LD))
hold off;

end

end